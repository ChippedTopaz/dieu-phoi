// 1. Gắn cờ báo hiệu cho trang web biết: "Cán bộ máy này ĐÃ CÀI Extension nhé!"
document.documentElement.setAttribute('data-extension-installed', 'true');

// 2. Lắng nghe tiếng hét "YeuCauMoAnDanh" từ hàm openNopHo của trang web
document.addEventListener("YeuCauMoAnDanh", function(e) {
    let targetUrl = e.detail.url;
    
    if (targetUrl) {
        // Bắn thông tin về cho não bộ của Extension xử lý
        chrome.runtime.sendMessage({ action: "openIncognito", url: targetUrl });
    }
});