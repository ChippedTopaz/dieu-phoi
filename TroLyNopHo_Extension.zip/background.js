chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Nhận được lệnh, tiến hành gọi API của Chrome để mở cửa sổ Ẩn danh
    if (request.action === "openIncognito") {
        chrome.windows.create({
            url: request.url,
            incognito: true,
            state: "maximized" // Ép mở toàn màn hình cho dễ làm việc
        });
    }
});